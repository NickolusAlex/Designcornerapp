<?php

$servername = "localhost";
$username = "id17502114_root_123";
$password = "l34bL=h}%5^P+v[=";
$db_name = "id17502114_design_corner_app";

$DB_conn = new PDO("mysql:host=$servername;dbname=$db_name", $username, $password);
